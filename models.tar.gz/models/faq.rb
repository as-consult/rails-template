class Faq < ApplicationRecord
end
